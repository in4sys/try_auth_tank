 <!doctype html>
<html lang="en" dir="ltr">
    <head>
    	<meta charset="utf-8">
        <title>Login</title>
        
        
 <link rel="stylesheet" href="/css/main.css" />
<link rel="stylesheet" type="text/css" href="<? echo base_url();?>/css/all.css">
</head>
<header> <?php echo $heading; ?> </header>